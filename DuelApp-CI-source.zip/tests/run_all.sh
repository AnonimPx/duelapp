#!/bin/bash
# Esegue tutti gli SQL su un Postgres locale (stub minimo di Supabase) e gli scenari di test.
# Uso (come root, Postgres installato): bash tests/run_all.sh
set -e
cd "$(dirname "$0")/.."
ROOT=$(pwd)
service postgresql start >/dev/null 2>&1 || true; sleep 2
su postgres -c "psql -qc 'drop database if exists duel' -c 'create database duel'"
for f in tests/bootstrap.sql schema.sql functions.sql functions_scacchi.sql functions_maintenance.sql functions_profile.sql tests/scenario.sql tests/profile_scenario.sql; do
  chmod 644 "$ROOT/$f"
  echo "== $f"
  su postgres -c "psql -v ON_ERROR_STOP=1 -q duel -f $ROOT/$f" 2>&1 | grep -E "ERROR|NOTICE|OK|assert|WARNING:  wal" || true
done

# Test logica Dama (richiede node e tsc)
if command -v tsc >/dev/null 2>&1 && command -v node >/dev/null 2>&1; then
  T=$(mktemp -d)
  cp "$(dirname "$0")/../supabase/functions/dama-move/dama.ts" "$T/dama.ts"
  sed "s#../supabase/functions/dama-move/dama.ts#./dama.ts#" "$(dirname "$0")/dama_test.ts" > "$T/test.ts"
  (cd "$T" && tsc --strict --target es2020 --module commonjs --allowImportingTsExtensions --outDir out --rewriteRelativeImportExtensions test.ts \
    && sed -i 's#./dama.ts#./dama.js#' out/test.js && node out/test.js)
fi

# Test logica Forza 4 e Tris Pro
if command -v tsc >/dev/null 2>&1 && command -v node >/dev/null 2>&1; then
  R="$(cd "$(dirname "$0")/.." && pwd)"
  T=$(mktemp -d); mkdir "$T/supabase" "$T/tests"
  cp -r "$R/supabase/functions" "$T/supabase/"; cp "$R/tests/f4_tris_test.ts" "$T/tests/"
  (cd "$T" && tsc --strict --target es2020 --module commonjs --allowImportingTsExtensions --outDir out --rewriteRelativeImportExtensions tests/f4_tris_test.ts >/dev/null 2>&1
   F=$(find out -name f4_tris_test.js); sed -i "s#\.ts'#.js'#" "$F"; node "$F")
fi
