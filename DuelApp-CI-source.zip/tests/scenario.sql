\set ON_ERROR_STOP on
insert into auth.users (id, raw_user_meta_data) values
 ('00000000-0000-0000-0000-00000000000a', '{"username":"alice"}'),
 ('00000000-0000-0000-0000-00000000000b', '{"username":"bob"}'),
 ('00000000-0000-0000-0000-00000000000c', '{}');
select username, elo_global from public.users order by username;
select user_id, balance_gems, hold_gems from public.wallets order by user_id;

-- alice crea sfida a dama 100
set app.uid = '00000000-0000-0000-0000-00000000000a';
select public.create_challenge((select id from public.games where slug='dama'), 100) as challenge \gset
\echo challenge :challenge
-- alice non puo' accettare la propria
do $$ begin perform public.accept_challenge((select id from public.challenges limit 1)); exception when others then raise notice 'OK errore atteso: %', sqlerrm; end $$;
-- bob accetta
set app.uid = '00000000-0000-0000-0000-00000000000b';
select public.accept_challenge(:'challenge') as match \gset
select stake_gems, fee_gems, prize_gems, status, substr(game_data->>'board',1,16) b, game_data->>'turn' t from public.matches;
select user_id, balance_gems, hold_gems from public.wallets order by user_id;

-- finish: vince alice (server)
select public.finish_match(:'match', '00000000-0000-0000-0000-00000000000a');
select public.finish_match(:'match', '00000000-0000-0000-0000-00000000000b'); -- idempotente: nessun effetto
select user_id, balance_gems, hold_gems from public.wallets order by user_id;
select u.username, u.elo_global, u.xp, u.level from public.users u order by username;
select type, amount_gems, balance_before, balance_after, user_id from public.transactions order by created_at, type;
select * from public.platform_fees;

-- annulla sfida: rimborso
set app.uid = '00000000-0000-0000-0000-00000000000a';
select public.create_challenge((select id from public.games where slug='forza4'), 50) as ch2 \gset
select public.cancel_challenge(:'ch2');
select balance_gems, hold_gems from public.wallets where user_id='00000000-0000-0000-0000-00000000000a';

-- partita ferma: carlo (c) e alice, alice ha il turno e non muove -> perde
update public.wallets set balance_gems = 1000 where user_id = '00000000-0000-0000-0000-00000000000a';
select public.create_challenge((select id from public.games where slug='tris_pro'), 200) as ch3 \gset
set app.uid = '00000000-0000-0000-0000-00000000000c';
select public.accept_challenge(:'ch3') as m3 \gset
update public.matches set game_data = jsonb_set(game_data, '{last_move_at}', to_jsonb(((extract(epoch from now())*1000)::bigint - 11*60000))) where id = :'m3';
select public.close_stale_matches(10) as chiuse;
select status, winner_id from public.matches where id = :'m3';
select user_id, balance_gems, hold_gems from public.wallets order by user_id;
-- invariante: gemme totali = 3000 - fee
select sum(balance_gems + hold_gems) totale, (select coalesce(sum(fee_gems),0) from public.platform_fees) fee, 3000 + 0 as iniziali from public.wallets;
-- permessi: authenticated NON puo' chiamare finish_match
set role authenticated;
do $$ begin perform public.finish_match(gen_random_uuid(), null); exception when others then raise notice 'OK permesso negato: %', sqlerrm; end $$;
