import { drop, wins, ROWS, COLS } from '../supabase/functions/forza4-move/forza4.ts';
import { place, hasWon } from '../supabase/functions/tris-move/tris.ts';
let ok = 0, ko = 0;
const t = (n: string, c: boolean) => { c ? ok++ : ko++; console.log((c ? 'OK  ' : 'FAIL ') + n); };
const empty4 = '.'.repeat(ROWS * COLS);

// Forza 4
let r: any = drop(empty4, 3, 'r');
t('f4: disco cade in fondo', r.row === 5 && r.board[5 * COLS + 3] === 'r');
r = drop(r.board, 3, 'y');
t('f4: secondo disco sopra', r.row === 4);
t('f4: colonna non valida', 'error' in (drop(empty4, 7, 'r') as any) && 'error' in (drop(empty4, -1, 'r') as any));
let full = empty4;
for (let i = 0; i < ROWS; i++) full = (drop(full, 0, i % 2 ? 'y' : 'r') as any).board;
t('f4: colonna piena', (drop(full, 0, 'r') as any).error === 'column_full');
let b = empty4;
for (let c = 0; c < 4; c++) b = (drop(b, c, 'r') as any).board;
t('f4: vittoria orizzontale', wins(b, 5, 3));
b = empty4; let last = 0;
for (let i = 0; i < 4; i++) { const x: any = drop(b, 2, 'y'); b = x.board; last = x.row; }
t('f4: vittoria verticale', wins(b, last, 2));
// diagonale: r in (5,0),(4,1),(3,2),(2,3)
const arr = empty4.split('');
for (const [rr, cc] of [[5, 0], [4, 1], [3, 2], [2, 3]]) arr[rr * COLS + cc] = 'r';
t('f4: vittoria diagonale', wins(arr.join(''), 3, 2));
const arr2 = empty4.split('');
for (const [rr, cc] of [[5, 3], [4, 2], [3, 1], [2, 0]]) arr2[rr * COLS + cc] = 'y';
t('f4: vittoria anti-diagonale', wins(arr2.join(''), 4, 2));
const three = empty4.split(''); for (let c = 0; c < 3; c++) three[5 * COLS + c] = 'r';
t('f4: tre in fila non vincono', !wins(three.join(''), 5, 1));

// Tris Pro
let board = '.........', q: number[] = [];
let p: any = place(board, q, 4, 'x'); board = p.board; q = p.queue;
t('tris: piazza segno', board[4] === 'x' && q.length === 1);
t('tris: casella occupata', (place(board, q, 4, 'o') as any).error === 'cell_taken');
t('tris: casella fuori range', (place(board, q, 9, 'o') as any).error === 'bad_cell');
board = '.........'; q = [];
for (const c of [0, 1, 2]) { p = place(board, q, c, 'x'); board = p.board; q = p.queue; }
p = place(board, q, 8, 'x');
t('tris: il quarto segno fa sparire il piu\' vecchio', p.board[0] === '.' && p.board[8] === 'x' && p.queue.join() === '1,2,8');
t('tris: vittoria riga', hasWon('xxx......', 'x') && !hasWon('xxx......', 'o'));
t('tris: vittoria diagonale', hasWon('o...o...o', 'o') && hasWon('..x.x.x..', 'x'));
t('tris: nessuna vittoria', !hasWon('xo.ox.o..', 'x'));
// la scomparsa puo' impedire una vittoria apparente: x in 0,1,2 poi 4 -> 0 sparisce
p = place('xxx......', [0, 1, 2], 4, 'x');
t('tris: dopo la scomparsa la riga non e\' piu\' completa', !hasWon(p.board, 'x'));

console.log(ok, 'ok', ko, 'fail');
if (ko) throw new Error('test falliti');
