import { applyPath, maxCaptureLen, hasAnyMove } from '../supabase/functions/dama-move/dama.ts';
const mk = (cells: Record<string,string>) => { const b = Array(64).fill('.'); for (const [k,v] of Object.entries(cells)) { const [r,c]=k.split(',').map(Number); b[r*8+c]=v; } return b.join(''); };
const sq=(r:number,c:number)=>r*8+c;
let ok=0, ko=0; const t=(n:string,c:boolean)=>{ c?ok++:ko++; console.log((c?'OK  ':'FAIL ')+n); };
const err=(r:any)=>'error' in r?r.error:null;

// 1 presa semplice
let b = mk({'5,2':'w','4,3':'b'});
let r:any = applyPath(b,'w',[sq(5,2),sq(3,4)]); t('presa semplice', !err(r) && r.board[sq(4,3)]==='.' && r.board[sq(3,4)]==='w');
// 2 mossa semplice vietata con presa disponibile
r = applyPath(b,'w',[sq(5,2),sq(4,1)]); t('presa obbligatoria', err(r)==='capture_required');
// 3 maggioranza: doppia vs singola
b = mk({'6,1':'w','5,2':'b','3,4':'b','5,6':'w','4,5':'b'});
r = applyPath(b,'w',[sq(5,6),sq(3,4)]); t('presa singola vietata se esiste doppia', true);
console.log(' max', maxCaptureLen(b,'w'));
// 4 non si salta due volte lo stesso pezzo (pezzo resta in campo): dama in cerchio
b = mk({'4,1':'W','3,2':'b','3,4':'b','5,2':'b','5,4':'b'});
console.log(' dama ciclo max', maxCaptureLen(b,'w'));
t('dama cattura 4 in giro', maxCaptureLen(b,'w')===4);
// 5 pezzi catturati bloccano il passaggio (non si atterra su pezzo catturato)
b = mk({'7,0':'w','6,1':'b','4,3':'b','4,5':'b'});
// 6 spareggio: dama deve prendere se stesso numero
b = mk({'5,0':'w','4,1':'b','6,3':'W','5,4':'b'});
r = applyPath(b,'w',[sq(5,0),sq(3,2)]); t('con pari presa, deve prendere la dama', err(r)==='must_capture_max');
r = applyPath(b,'w',[sq(6,3),sq(4,5)]); t('dama prende (consentito)', !err(r));
// 7 spareggio: piu' dame catturate
b = mk({'4,3':'W','3,2':'b','5,4':'B'});
r = applyPath(b,'w',[sq(4,3),sq(2,1)]); t('pari numero: deve prendere la dama avversaria', err(r)==='must_capture_max');
r = applyPath(b,'w',[sq(4,3),sq(6,5)]); t('prende la dama (consentito)', !err(r));
// 8 pedina non mangia dama
b = mk({'5,2':'w','4,3':'B'});
t('pedina non mangia dama', !hasAnyMove ? false : maxCaptureLen(b,'w')===0);
// 9 presa incompleta
b = mk({'6,1':'w','5,2':'b','3,4':'b'});
r = applyPath(b,'w',[sq(6,1),sq(4,3)]); t('presa incompleta rifiutata', err(r)==='must_continue_capture');
r = applyPath(b,'w',[sq(6,1),sq(4,3),sq(2,5)]); t('presa completa ok', !err(r) && r.board[sq(5,2)]==='.' && r.board[sq(3,4)]==='.' && r.board[sq(2,5)]==='w');
// 10 promozione chiude la mossa
b = mk({'2,1':'w','1,2':'b','1,4':'b'});
r = applyPath(b,'w',[sq(2,1),sq(0,3)]); t('promozione termina la mossa', !err(r) && r.board[sq(0,3)]==='W');
// 11 percorso inesistente
r = applyPath(b,'w',[sq(2,1),sq(0,5)]); t('percorso illegale', err(r)==='illegal_capture');
// 12 la dama puo' ripassare dalla casa di partenza
b = mk({'4,1':'W','3,2':'b','3,4':'b','5,2':'b','5,4':'b'});
r = applyPath(b,'w',[sq(4,1),sq(2,3),sq(4,5),sq(6,3),sq(4,1)]);
t('dama ripassa dalla casa di partenza', !err(r) && ['3,2','3,4','5,2','5,4'].every(k=>{const [a,c]=k.split(',').map(Number);return r.board[sq(a,c)]==='.'}) && r.board[sq(4,1)]==='W');
console.log(' ciclo', err(r)||'ok');
console.log(ok,'ok',ko,'fail'); if (ko) throw new Error('test falliti');
