-- Va eseguito DOPO tests/scenario.sql (usa gli stessi utenti: alice, bob, carlo).
\set ON_ERROR_STOP on
\set A '00000000-0000-0000-0000-00000000000a'
\set B '00000000-0000-0000-0000-00000000000b'
\set C '00000000-0000-0000-0000-00000000000c'

-- statistiche dopo lo scenario base: alice vince a dama, perde a tris; bob perde a dama; carlo vince a tris
do $$ declare d uuid := (select id from public.games where slug='dama'); t uuid := (select id from public.games where slug='tris_pro'); begin
  assert (select wins from public.user_game_stats where user_id='00000000-0000-0000-0000-00000000000a' and game_id=d) = 1, 'alice dama wins';
  assert (select elo from public.user_game_stats where user_id='00000000-0000-0000-0000-00000000000a' and game_id=d) = 1015, 'alice dama elo';
  assert (select losses from public.user_game_stats where user_id='00000000-0000-0000-0000-00000000000a' and game_id=t) = 1, 'alice tris losses';
  assert (select elo from public.user_game_stats where user_id='00000000-0000-0000-0000-00000000000b' and game_id=d) = 985, 'bob dama elo';
  assert (select streak from public.user_game_stats where user_id='00000000-0000-0000-0000-00000000000c' and game_id=t) = 1, 'carlo streak';
end $$;

-- seconda vittoria di alice a dama: serie 2
set app.uid = :'A';
select public.create_challenge((select id from public.games where slug='dama'), 100) as c1 \gset
set app.uid = :'B';
select public.accept_challenge(:'c1') as m1 \gset
select public.finish_match(:'m1', :'A');
-- pareggio a forza4
set app.uid = :'A';
select public.create_challenge((select id from public.games where slug='forza4'), 50) as c2 \gset
set app.uid = :'B';
select public.accept_challenge(:'c2') as m2 \gset
select public.finish_match(:'m2', null);

do $$ declare d uuid := (select id from public.games where slug='dama'); f uuid := (select id from public.games where slug='forza4'); begin
  assert (select streak from public.user_game_stats where user_id='00000000-0000-0000-0000-00000000000a' and game_id=d) = 2, 'serie 2';
  assert (select best_streak from public.user_game_stats where user_id='00000000-0000-0000-0000-00000000000a' and game_id=d) = 2, 'best 2';
  assert (select elo from public.user_game_stats where user_id='00000000-0000-0000-0000-00000000000a' and game_id=d) = 1030, 'elo 1030';
  assert (select draws from public.user_game_stats where user_id='00000000-0000-0000-0000-00000000000a' and game_id=f) = 1, 'draw';
  assert (select played from public.user_game_stats where user_id='00000000-0000-0000-0000-00000000000b' and game_id=f) = 1, 'bob played';
  assert (select hold_gems from public.wallets where user_id='00000000-0000-0000-0000-00000000000a') = 0, 'hold rilasciato';
end $$;

-- nick e avatar
select public.check_username('alice') as alice_libero, public.check_username('ALICE') as ALICE_libero, public.check_username('nuovo_nick') as nuovo_libero;
set app.uid = :'A';
select public.update_profile('Alice_Pro', '👑', 'orange');
select username, avatar, avatar_color from public.users where id = :'A';
do $$ begin perform public.update_profile('bob', '🦊', 'blue'); exception when others then raise notice 'OK atteso: %', sqlerrm; end $$;
do $$ begin perform public.update_profile('BOB', '🦊', 'blue'); exception when others then raise notice 'OK atteso (maiuscole): %', sqlerrm; end $$;
do $$ begin perform public.update_profile('a b', '🦊', 'blue'); exception when others then raise notice 'OK atteso: %', sqlerrm; end $$;
do $$ begin perform public.update_profile('okname', 'X', 'blue'); exception when others then raise notice 'OK atteso: %', sqlerrm; end $$;
do $$ begin perform public.update_profile('okname', '🦊', 'viola'); exception when others then raise notice 'OK atteso: %', sqlerrm; end $$;
-- il proprio nick (anche cambiando solo l'avatar) deve funzionare
select public.update_profile('Alice_Pro', '🚀', 'teal');
select username, avatar, avatar_color from public.users where id = :'A';
\echo PROFILO: TUTTO OK
