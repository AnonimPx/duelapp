import 'dart:async';

import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import 'audio.dart';
import 'connection.dart';
import 'screens/auth_screen.dart';
import 'screens/home_screen.dart';
import 'supa.dart';
import 'theme.dart';

const _url = String.fromEnvironment('SUPABASE_URL');
const _anon = String.fromEnvironment('SUPABASE_ANON_KEY');

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  runApp(const _Bootstrap());
}

class _Bootstrap extends StatefulWidget {
  const _Bootstrap();

  @override
  State<_Bootstrap> createState() => _BootstrapState();
}

class _BootstrapState extends State<_Bootstrap> {
  bool _ready = false;
  String? _error;

  @override
  void initState() {
    super.initState();
    unawaited(_initialize());
  }

  Future<void> _initialize() async {
    if (_url.isEmpty || _anon.isEmpty) {
      if (mounted) setState(() => _error = 'Configurazione Supabase mancante.');
      return;
    }

    try {
      await Supabase.initialize(url: _url, anonKey: _anon)
          .timeout(const Duration(seconds: 20));
      // L'audio è opzionale: non deve impedire l'apertura dell'app.
      unawaited(Sfx.i.init().timeout(const Duration(seconds: 8)).catchError((_) {}));
      ConnectionMonitor.i.start();
      if (mounted) setState(() => _ready = true);
    } catch (e) {
      if (mounted) {
        setState(() => _error = 'Inizializzazione non riuscita: $e');
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    if (_ready) return const DuelApp();

    return MaterialApp(
      title: 'DuelApp',
      debugShowCheckedModeBanner: false,
      theme: buildTheme(),
      home: Scaffold(
        body: Center(
          child: Padding(
            padding: const EdgeInsets.all(28),
            child: _error == null
                ? const Column(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      CircularProgressIndicator(),
                      SizedBox(height: 20),
                      Text('Avvio DuelApp…'),
                    ],
                  )
                : Column(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      const Icon(Icons.error_outline, size: 40),
                      const SizedBox(height: 16),
                      SelectableText(_error!, textAlign: TextAlign.center),
                    ],
                  ),
          ),
        ),
      ),
    );
  }
}

class DuelApp extends StatelessWidget {
  const DuelApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'DuelApp',
      debugShowCheckedModeBanner: false,
      theme: buildTheme(),
      builder: (context, child) =>
          ConnectionBanner(child: child ?? const SizedBox.shrink()),
      home: StreamBuilder<AuthState>(
        stream: supa.auth.onAuthStateChange,
        builder: (context, _) => supa.auth.currentSession == null
            ? const AuthScreen()
            : const HomeScreen(),
      ),
    );
  }
}
