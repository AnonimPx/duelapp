import 'package:flutter/material.dart';
import '../audio.dart';
import '../avatars.dart';
import '../supa.dart';
import '../theme.dart';

/// Classifica globale e per gioco (ELO). I dati sono pubblici per RLS.
class LeaderboardTab extends StatefulWidget {
  const LeaderboardTab({super.key});
  @override
  State<LeaderboardTab> createState() => _LeaderboardTabState();
}

class _LeaderboardTabState extends State<LeaderboardTab> {
  List<Map<String, dynamic>> _games = [];
  String? _game; // null = globale
  late Future<List<Map<String, dynamic>>> _rows = _fetch();

  @override
  void initState() {
    super.initState();
    supa.from('games').select('id,name,slug').eq('is_active', true).then((g) {
      if (mounted) setState(() => _games = List<Map<String, dynamic>>.from(g));
    }).catchError((_) {});
  }

  Future<List<Map<String, dynamic>>> _fetch() async {
    if (_game == null) {
      final r = await supa
          .from('users')
          .select('id,username,avatar,avatar_color,level,elo_global')
          .order('elo_global', ascending: false)
          .limit(50);
      return [
        for (final u in r) {...u, 'elo': u['elo_global']},
      ];
    }
    final st = await supa
        .from('user_game_stats')
        .select('user_id,elo')
        .eq('game_id', _game!)
        .order('elo', ascending: false)
        .limit(50);
    if (st.isEmpty) return [];
    final us = await supa
        .from('users')
        .select('id,username,avatar,avatar_color,level')
        .inFilter('id', [for (final s in st) s['user_id']]);
    final byId = {for (final u in us) u['id'] as String: u};
    return [
      for (final s in st)
        if (byId[s['user_id']] != null) {...byId[s['user_id']]!, 'elo': s['elo']},
    ];
  }

  void _reload() => setState(() => _rows = _fetch());

  @override
  Widget build(BuildContext context) {
    final uid = supa.auth.currentUser!.id;
    return Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      const Padding(
        padding: EdgeInsets.fromLTRB(20, 16, 20, 8),
        child: Text('🏆 Classifica', style: TextStyle(fontSize: 26, fontWeight: FontWeight.w900)),
      ),
      SizedBox(
        height: 44,
        child: ListView(
          scrollDirection: Axis.horizontal,
          padding: const EdgeInsets.symmetric(horizontal: 14),
          children: [
            _chip('Globale', null),
            for (final g in _games) _chip('${g['name']}', g['id'] as String),
          ],
        ),
      ),
      Expanded(
        child: FutureBuilder<List<Map<String, dynamic>>>(
          future: _rows,
          builder: (c, s) {
            if (s.hasError) {
              return Center(
                child: Column(mainAxisSize: MainAxisSize.min, children: [
                  const Text('Impossibile caricare la classifica.'),
                  TextButton(onPressed: _reload, child: const Text('Riprova')),
                ]),
              );
            }
            if (!s.hasData) return const Center(child: CircularProgressIndicator());
            final rows = s.data!;
            if (rows.isEmpty) {
              return const Center(child: Text('Nessuno in classifica per questo gioco.\nGioca la prima partita!', textAlign: TextAlign.center));
            }
            return RefreshIndicator(
              onRefresh: () async {
                _reload();
                await _rows;
              },
              child: ListView.builder(
                padding: const EdgeInsets.fromLTRB(14, 10, 14, 20),
                itemCount: rows.length,
                itemBuilder: (_, i) => _row(i, rows[i], rows[i]['id'] == uid),
              ),
            );
          },
        ),
      ),
    ]);
  }

  Widget _chip(String label, String? id) => Padding(
        padding: const EdgeInsets.only(right: 8),
        child: ChoiceChip(
          label: Text(label),
          selected: _game == id,
          onSelected: (_) {
            Sfx.i.play('tap');
            _game = id;
            _reload();
          },
        ),
      );

  Widget _row(int i, Map<String, dynamic> u, bool me) {
    const medals = ['🥇', '🥈', '🥉'];
    return GlassCard(
      margin: const EdgeInsets.symmetric(vertical: 4),
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
      tint: me ? Pal.violet.withValues(alpha: 0.22) : null,
      child: Row(children: [
        SizedBox(
          width: 36,
          child: i < 3
              ? Text(medals[i], style: const TextStyle(fontSize: 24))
              : Text('${i + 1}', textAlign: TextAlign.center, style: const TextStyle(fontWeight: FontWeight.w800, color: Colors.white60)),
        ),
        AvatarCircle(emoji: u['avatar'] as String, color: u['avatar_color'] as String, size: 40),
        const SizedBox(width: 12),
        Expanded(
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text(me ? '${u['username']} (tu)' : '${u['username']}',
                overflow: TextOverflow.ellipsis, style: const TextStyle(fontWeight: FontWeight.w800)),
            Text('${levelTitle(u['level'] as int)} · liv. ${u['level']}', style: const TextStyle(color: Colors.white60, fontSize: 12)),
          ]),
        ),
        Text('${u['elo']}', style: const TextStyle(fontSize: 20, fontWeight: FontWeight.w900, color: Pal.cyan)),
        const SizedBox(width: 4),
        const Text('ELO', style: TextStyle(fontSize: 10, color: Colors.white54)),
      ]),
    );
  }
}
