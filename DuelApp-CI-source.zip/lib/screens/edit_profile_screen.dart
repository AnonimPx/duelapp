import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import '../audio.dart';
import '../avatars.dart';
import '../supa.dart';
import '../theme.dart';
import '../widgets.dart';

class EditProfileScreen extends StatefulWidget {
  final String username, avatar, color;
  const EditProfileScreen({super.key, required this.username, required this.avatar, required this.color});
  @override
  State<EditProfileScreen> createState() => _EditProfileScreenState();
}

class _EditProfileScreenState extends State<EditProfileScreen> {
  late final _nick = TextEditingController(text: widget.username);
  late String _avatar = widget.avatar;
  late String _color = widget.color;
  bool _busy = false;

  Future<void> _save() async {
    final nick = _nick.text.trim();
    if (!nickRegex.hasMatch(nick)) {
      toast(context, errText('username_invalid'), error: true);
      return;
    }
    setState(() => _busy = true);
    try {
      await supa.rpc('update_profile', params: {'p_username': nick, 'p_avatar': _avatar, 'p_color': _color});
      Sfx.i.play('coin', haptic: true);
      if (mounted) Navigator.pop(context);
    } on PostgrestException catch (e) {
      toast(context, errText(e.message), error: true);
    } catch (e) {
      toast(context, 'Connessione instabile, riprova.', error: true);
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return GScaffold(
      appBar: AppBar(title: const Text('Modifica profilo')),
      body: ListView(padding: const EdgeInsets.all(20), children: [
        Center(child: AvatarCircle(emoji: _avatar, color: _color, size: 96)),
        const SizedBox(height: 20),
        TextField(
          controller: _nick,
          maxLength: 20,
          decoration: const InputDecoration(labelText: 'Nick', helperText: 'Lettere, numeri e _ (3-20 caratteri)'),
        ),
        const SizedBox(height: 12),
        const Text('Avatar', style: TextStyle(fontWeight: FontWeight.bold)),
        const SizedBox(height: 8),
        Wrap(spacing: 8, runSpacing: 8, children: [
          for (final a in kAvatars)
            InkWell(
              borderRadius: BorderRadius.circular(12),
              onTap: () => setState(() => _avatar = a),
              child: Container(
                width: 52,
                height: 52,
                alignment: Alignment.center,
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(12),
                  color: a == _avatar ? Pal.gold.withValues(alpha: 0.15) : Colors.white10,
                  border: Border.all(
                    color: a == _avatar ? Pal.gold : Colors.white24,
                    width: a == _avatar ? 3 : 1,
                  ),
                ),
                child: Text(a, style: const TextStyle(fontSize: 28)),
              ),
            ),
        ]),
        const SizedBox(height: 20),
        const Text('Colore', style: TextStyle(fontWeight: FontWeight.bold)),
        const SizedBox(height: 8),
        Wrap(spacing: 10, runSpacing: 10, children: [
          for (final e in kAvatarColors.entries)
            GestureDetector(
              onTap: () => setState(() => _color = e.key),
              child: CircleAvatar(
                radius: 20,
                backgroundColor: e.value,
                child: e.key == _color ? const Icon(Icons.check, color: Colors.white) : null,
              ),
            ),
        ]),
        const SizedBox(height: 28),
        FilledButton(onPressed: _busy ? null : _save, child: const Text('Salva')),
      ]),
    );
  }
}
