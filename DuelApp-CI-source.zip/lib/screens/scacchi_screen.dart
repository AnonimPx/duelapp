import 'dart:async';
import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import 'package:url_launcher/url_launcher.dart';
import '../audio.dart';
import '../supa.dart';
import '../theme.dart';
import '../widgets.dart';

/// Scacchi: la partita si gioca su Lichess (link anonimo); qui si legge il risultato.
class ScacchiScreen extends StatelessWidget {
  final String matchId;
  const ScacchiScreen({super.key, required this.matchId});

  @override
  Widget build(BuildContext context) {
    return GameShell(
      matchId: matchId,
      title: 'Scacchi (Lichess)',
      fn: 'scacchi-lichess',
      isMyTurn: (gd, isP1) => false,
      showTurn: false,
      serverActions: false,
      sideP1: 'Bianco',
      sideP2: 'Nero',
      colorP1: const Color(0xFFF1F3FF),
      colorP2: Pal.violet,
      boardBuilder: (_, ctx) => SingleChildScrollView(child: ScacchiPanel(ctx: ctx)),
    );
  }
}

class ScacchiPanel extends StatefulWidget {
  final MatchCtx ctx;
  const ScacchiPanel({super.key, required this.ctx});
  @override
  State<ScacchiPanel> createState() => _ScacchiPanelState();
}

class _ScacchiPanelState extends State<ScacchiPanel> {
  Timer? _timer;
  bool _busy = false;

  @override
  void initState() {
    super.initState();
    _init();
    _timer = Timer.periodic(const Duration(seconds: 10), (_) {
      if (!widget.ctx.finished) _call('sync', silent: true);
    });
  }

  @override
  void dispose() {
    _timer?.cancel();
    super.dispose();
  }

  // Il bianco (player1) crea la partita su Lichess alla prima apertura.
  Future<void> _init() async {
    final c = widget.ctx;
    if (c.isP1 && c.gd['lichess_id'] == null && !c.finished) {
      await _call('start', silent: true);
    }
  }

  Future<void> _call(String action, {bool silent = false}) async {
    if (!silent && mounted) setState(() => _busy = true);
    try {
      await supa.functions.invoke('scacchi-lichess', body: {'match_id': widget.ctx.match['id'], 'action': action});
    } on FunctionException catch (e) {
      final d = e.details;
      if (!silent && mounted) toast(context, errText(d is Map ? d['error'] : d), error: true);
    } catch (_) {
      if (!silent && mounted) toast(context, 'Connessione instabile, riprova.', error: true);
    } finally {
      if (!silent && mounted) setState(() => _busy = false);
    }
  }

  Future<void> _open(String url) async {
    Sfx.i.play('tap', haptic: true);
    final ok = await launchUrl(Uri.parse(url), mode: LaunchMode.externalApplication);
    if (!ok && mounted) toast(context, 'Impossibile aprire il link.', error: true);
  }

  @override
  Widget build(BuildContext context) {
    final c = widget.ctx;
    final url = (c.isP1 ? c.gd['url_white'] : c.gd['url_black']) as String?;
    final style = gameStyle('scacchi');

    return GlassCard(
      padding: const EdgeInsets.all(22),
      child: Column(mainAxisSize: MainAxisSize.min, children: [
        Container(
          width: 84,
          height: 84,
          decoration: BoxDecoration(
            shape: BoxShape.circle,
            gradient: RadialGradient(colors: [style.color.withValues(alpha: 0.45), Colors.transparent]),
          ),
          child: Icon(style.icon, size: 52, color: style.color),
        ),
        const SizedBox(height: 10),
        Text(
          c.finished
              ? 'Partita conclusa'
              : (url == null ? 'Preparazione della partita…' : 'Partita pronta'),
          style: const TextStyle(fontSize: 20, fontWeight: FontWeight.w800),
        ),
        const SizedBox(height: 14),
        if (!c.finished && url != null) ...[
          FilledButton.icon(
            onPressed: () => _open(url),
            icon: const Icon(Icons.open_in_new),
            label: const Text('Apri la partita su Lichess'),
          ),
          const SizedBox(height: 12),
          const Text(
            'Si gioca sul sito di Lichess (10 minuti a testa). Il risultato viene letto da solo entro pochi secondi.',
            textAlign: TextAlign.center,
            style: TextStyle(color: Colors.white60, fontSize: 12),
          ),
          const SizedBox(height: 8),
          OutlinedButton.icon(
            onPressed: _busy ? null : () => _call('sync'),
            icon: const Icon(Icons.refresh),
            label: const Text('Aggiorna risultato'),
          ),
        ],
        if (!c.finished && url == null && !c.isP1) ...[
          const CircularProgressIndicator(),
          const SizedBox(height: 10),
          const Text('Attendi: il bianco sta creando la partita.', textAlign: TextAlign.center),
        ],
        if (!c.finished && url == null && c.isP1)
          OutlinedButton(
            onPressed: _busy ? null : () => _call('start'),
            child: const Text('Riprova a creare la partita'),
          ),
      ]),
    );
  }
}
