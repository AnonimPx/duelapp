import 'package:flutter/material.dart';
import '../theme.dart';
import '../widgets.dart';

class Scala40Screen extends StatelessWidget {
  final String matchId;
  const Scala40Screen({super.key, required this.matchId});

  @override
  Widget build(BuildContext context) => GameShell(
        matchId: matchId,
        title: 'Scala 40',
        fn: 'scala40-move',
        isMyTurn: (gd, _) {
          final players = (gd['players'] as List?) ?? const [];
          final uid = (gd['current_user_id'] ?? '').toString();
          final index = players.indexWhere((p) => p is Map && '${p['id']}' == uid);
          return index >= 0 && gd['turn'] == index;
        },
        sideP1: 'Giocatore 1',
        sideP2: 'Giocatore 2',
        colorP1: Pal.cyan,
        colorP2: Pal.pink,
        hint: 'Pesca, apri a 40, cala e scarta.',
        serverActions: false,
        rules: 'Tavolo da 2 a 4 giocatori. Chi apre il tavolo sceglie la puntata per persona. Partita secca: si apre con combinazioni che totalizzano almeno 40 punti; dopo la prima apertura si possono calare altre combinazioni e attaccare carte. Vince chi chiude per primo la mano. Il banco trattiene il 20% del piatto e il vincitore riceve l’80%.',
        boardBuilder: (_, ctx) => Scala40Board(ctx: ctx),
      );
}

class Scala40Board extends StatefulWidget {
  final MatchCtx ctx;
  const Scala40Board({super.key, required this.ctx});

  @override
  State<Scala40Board> createState() => _Scala40BoardState();
}

class _Scala40BoardState extends State<Scala40Board> {
  final Set<int> _selected = {};
  final List<List<Map<String, dynamic>>> _pendingMelds = [];
  int? _targetMeld;

  Map<String, dynamic>? get me {
    final players = (widget.ctx.gd['players'] as List?) ?? const [];
    for (final value in players) {
      if (value is Map && '${value['id']}' == widget.ctx.uid) {
        return Map<String, dynamic>.from(value);
      }
    }
    return null;
  }

  String _card(dynamic value) {
    final c = Map<String, dynamic>.from(value as Map);
    if (c['joker'] == true) return 'Jolly';
    const ranks = {1: 'A', 11: 'J', 12: 'Q', 13: 'K'};
    return '${ranks[c['rank']] ?? c['rank']}${c['suit']}';
  }

  List<Map<String, dynamic>> _picked(List hand) =>
      _selected.map((i) => Map<String, dynamic>.from(hand[i] as Map)).toList();

  Future<void> _draw(bool fromDiscard) async {
    await widget.ctx.call('draw', {'from_discard': fromDiscard});
    if (mounted) setState(() { _selected.clear(); _pendingMelds.clear(); });
  }

  Future<void> _discard(List hand) async {
    if (_selected.length != 1) return;
    await widget.ctx.call('discard', {'card': hand[_selected.single]});
    if (mounted) setState(() { _selected.clear(); _pendingMelds.clear(); });
  }

  void _stageMeld(List hand) {
    if (_selected.length < 3) return;
    setState(() {
      _pendingMelds.add(_picked(hand));
      _selected.clear();
    });
  }

  Future<void> _layMelds(List hand) async {
    final groups = [..._pendingMelds.map((group) => group.map((c) => Map<String, dynamic>.from(c)).toList())];
    if (_selected.isNotEmpty) groups.add(_picked(hand));
    if (groups.isEmpty) return;
    await widget.ctx.call('meld', {'melds': groups});
    if (mounted) setState(() { _selected.clear(); _pendingMelds.clear(); });
  }

  Future<void> _layoff(List hand) async {
    if (_targetMeld == null || _selected.isEmpty) return;
    await widget.ctx.call('layoff', {
      'meld_index': _targetMeld,
      'cards': _picked(hand),
    });
    if (mounted) setState(() => _selected.clear());
  }

  @override
  Widget build(BuildContext context) {
    final gd = widget.ctx.gd;
    final phase = '${gd['phase'] ?? 'waiting'}';
    if (phase == 'unavailable') {
      return Center(child: Column(mainAxisSize: MainAxisSize.min, children: [
        const Icon(Icons.cloud_off_rounded, size: 40, color: Colors.white54),
        const SizedBox(height: 8),
        const Text('Arbitro non raggiungibile. Le carte restano nascoste.'),
        const SizedBox(height: 12),
        FilledButton.tonal(onPressed: widget.ctx.busy ? null : () => widget.ctx.call('state'), child: const Text('Riprova')),
      ]));
    }
    if (phase == 'waiting') {
      final players = (gd['players'] as List?) ?? const [];
      return Center(child: Padding(
        padding: const EdgeInsets.all(20),
        child: Column(mainAxisSize: MainAxisSize.min, children: [
          const Icon(Icons.style_rounded, size: 46, color: Pal.pink),
          const SizedBox(height: 12),
          Text('Tavolo Scala 40 · ${players.length}/4 giocatori', style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w800)),
          const SizedBox(height: 8),
          const Text('Gli altri possono unirsi dalla lobby finché la partita non parte.', textAlign: TextAlign.center, style: TextStyle(color: Colors.white60)),
          const SizedBox(height: 18),
          FilledButton.icon(
            onPressed: widget.ctx.busy || widget.ctx.finished ? null : () => widget.ctx.call('start'),
            icon: const Icon(Icons.play_arrow_rounded),
            label: const Text('Avvia partita'),
          ),
        ]),
      ));
    }

    final player = me;
    final hand = (player?['hand'] as List?) ?? const [];
    final players = (gd['players'] as List?) ?? const [];
    final stockCount = (gd['stock_count'] as num?)?.toInt() ?? 0;
    final discard = (gd['discard'] as List?) ?? const [];
    final melds = (gd['melds'] as List?) ?? const [];
    final drawn = gd['drawn'] == true;
    final canAct = widget.ctx.myTurn && !widget.ctx.busy && !widget.ctx.finished;

    return Column(children: [
      Wrap(
        spacing: 6,
        runSpacing: 4,
        alignment: WrapAlignment.center,
        children: [
          for (var i = 0; i < players.length; i++)
            Chip(
              avatar: CircleAvatar(child: Text('${i + 1}')),
              label: Text('${(players[i] as Map)['cards_count'] ?? 0} carte'),
              backgroundColor: gd['turn'] == i && phase == 'playing'
                  ? Pal.green.withValues(alpha: 0.22)
                  : Colors.white.withValues(alpha: 0.07),
            ),
        ],
      ),
      const SizedBox(height: 6),
      if (melds.isNotEmpty)
        SizedBox(
          height: 82,
          child: ListView.separated(
            scrollDirection: Axis.horizontal,
            itemCount: melds.length,
            separatorBuilder: (_, __) => const SizedBox(width: 6),
            itemBuilder: (_, i) {
              final meld = Map<String, dynamic>.from(melds[i] as Map);
              final cards = (meld['cards'] as List?) ?? const [];
              return ChoiceChip(
                selected: _targetMeld == i,
                onSelected: (_) => setState(() => _targetMeld = i),
                label: Text('T${i + 1}: ${cards.map(_card).join(' ')}'),
              );
            },
          ),
        ),
      Row(mainAxisAlignment: MainAxisAlignment.center, children: [
        FilledButton.tonalIcon(
          onPressed: canAct && !drawn && stockCount > 0 ? () => _draw(false) : null,
          icon: const Icon(Icons.layers_rounded),
          label: Text('Mazzo $stockCount'),
        ),
        const SizedBox(width: 8),
        FilledButton.tonalIcon(
          onPressed: canAct && !drawn && discard.isNotEmpty ? () => _draw(true) : null,
          icon: const Icon(Icons.undo_rounded),
          label: Text(discard.isEmpty ? 'Scarti' : _card(discard.last)),
        ),
      ]),
      if (_pendingMelds.isNotEmpty)
        Padding(
          padding: const EdgeInsets.only(top: 4),
          child: Text('Combinazioni preparate: ${_pendingMelds.length}', style: const TextStyle(color: Pal.gold, fontSize: 12)),
        ),
      Expanded(
        child: SingleChildScrollView(
          child: Wrap(
            spacing: 6,
            runSpacing: 4,
            alignment: WrapAlignment.center,
            children: [
              for (var i = 0; i < hand.length; i++)
                GestureDetector(
                  onTap: canAct && drawn ? () => setState(() {
                    if (!_selected.add(i)) _selected.remove(i);
                  }) : null,
                  child: Card(
                    color: _selected.contains(i) ? Pal.gold.withValues(alpha: 0.8) : Pal.violet.withValues(alpha: 0.35),
                    child: Padding(
                      padding: const EdgeInsets.symmetric(horizontal: 9, vertical: 12),
                      child: Text(_card(hand[i]), style: const TextStyle(fontWeight: FontWeight.w800)),
                    ),
                  ),
                ),
            ],
          ),
        ),
      ),
      if (canAct && drawn)
        Wrap(spacing: 8, runSpacing: 4, alignment: WrapAlignment.center, children: [
          OutlinedButton(
            onPressed: _selected.length >= 3 ? () => _stageMeld(hand) : null,
            child: const Text('Aggiungi gruppo'),
          ),
          FilledButton.tonal(
            onPressed: (_selected.isNotEmpty || _pendingMelds.isNotEmpty) ? () => _layMelds(hand) : null,
            child: Text(player?['opened'] == true ? 'Cala' : 'Cala apertura'),
          ),
          if (melds.isNotEmpty)
            OutlinedButton(
              onPressed: _selected.isNotEmpty && _targetMeld != null ? () => _layoff(hand) : null,
              child: const Text('Attacca'),
            ),
          FilledButton(
            onPressed: _selected.length == 1 ? () => _discard(hand) : null,
            child: const Text('Scarta'),
          ),
          TextButton(
            onPressed: () => setState(() { _selected.clear(); _pendingMelds.clear(); }),
            child: const Text('Annulla selezione'),
          ),
        ]),
    ]);
  }
}
