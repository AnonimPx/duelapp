import 'package:audioplayers/audioplayers.dart';
import 'package:flutter/services.dart';
import 'package:shared_preferences/shared_preferences.dart';

/// Effetti sonori + vibrazione. Un player per suono, riusato; mute salvato su disco.
/// Suoni in assets/audio/: tap, move, capture, drop, turn, start, win, lose, draw, error, coin.
class Sfx {
  Sfx._();
  static final Sfx i = Sfx._();

  bool muted = false;
  final Map<String, AudioPlayer> _players = {};

  Future<void> init() async {
    try {
      final p = await SharedPreferences.getInstance();
      muted = p.getBool('muted') ?? false;
    } catch (_) {}
  }

  Future<void> setMuted(bool v) async {
    muted = v;
    try {
      final p = await SharedPreferences.getInstance();
      await p.setBool('muted', v);
    } catch (_) {}
  }

  Future<void> play(String name, {bool haptic = false}) async {
    if (haptic) HapticFeedback.lightImpact();
    if (muted) return;
    try {
      var pl = _players[name];
      if (pl == null) {
        pl = AudioPlayer();
        await pl.setReleaseMode(ReleaseMode.stop);
        _players[name] = pl;
      }
      await pl.stop();
      await pl.play(AssetSource('audio/$name.wav'));
    } catch (_) {
      // L'audio non deve mai bloccare il gioco.
    }
  }
}
