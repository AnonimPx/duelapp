import 'package:flutter/material.dart';

/// Devono coincidere con le liste di `update_profile` in functions_profile.sql.
const kAvatars = ['🦊', '🐼', '🐯', '🦁', '🐸', '🐙', '🦉', '🐲', '🚀', '👾', '🎮', '👑', '🔥', '⚡', '🧠', '🎯'];

const kAvatarColors = <String, Color>{
  'purple': Color(0xFF7E57C2),
  'blue': Color(0xFF42A5F5),
  'teal': Color(0xFF26A69A),
  'green': Color(0xFF66BB6A),
  'orange': Color(0xFFFFA726),
  'red': Color(0xFFEF5350),
  'pink': Color(0xFFEC407A),
  'grey': Color(0xFF78909C),
};

final nickRegex = RegExp(r'^[A-Za-z0-9_]{3,20}$');

/// Livello = 1 + XP/100 (stessa regola del server).
String levelTitle(int level) {
  if (level >= 20) return 'Leggenda';
  if (level >= 10) return 'Maestro';
  if (level >= 5) return 'Veterano';
  if (level >= 2) return 'Sfidante';
  return 'Novizio';
}

class AvatarCircle extends StatelessWidget {
  final String emoji;
  final String color;
  final double size;
  const AvatarCircle({super.key, required this.emoji, required this.color, this.size = 56});

  @override
  Widget build(BuildContext context) {
    final base = kAvatarColors[color] ?? kAvatarColors['purple']!;
    return Container(
      width: size,
      height: size,
      alignment: Alignment.center,
      decoration: BoxDecoration(
        shape: BoxShape.circle,
        gradient: RadialGradient(
          center: const Alignment(-0.4, -0.5),
          radius: 1.1,
          colors: [Color.lerp(base, Colors.white, 0.35)!, base, Color.lerp(base, Colors.black, 0.35)!],
        ),
        border: Border.all(color: Colors.white.withValues(alpha: 0.35), width: size > 60 ? 3 : 2),
        boxShadow: [BoxShadow(color: base.withValues(alpha: 0.5), blurRadius: size * 0.25)],
      ),
      child: Text(emoji, style: TextStyle(fontSize: size * 0.5)),
    );
  }
}
