// Tris Pro - logica pura, eseguita SOLO sul server.
// Regola: ogni giocatore ha al massimo 3 segni; piazzando il quarto sparisce il piu' vecchio.
// Board: 9 caratteri ('x', 'o', '.'), indici 0-8 da sinistra a destra, dall'alto in basso.
export type Mark = 'x' | 'o';
export const MAX_MARKS = 3;
export const MAX_MOVES = 60; // oltre questo numero di mosse la partita e' patta

const LINES = [
  [0, 1, 2], [3, 4, 5], [6, 7, 8],
  [0, 3, 6], [1, 4, 7], [2, 5, 8],
  [0, 4, 8], [2, 4, 6],
];

export function place(board: string, queue: number[], cell: number, mark: Mark):
  { board: string; queue: number[] } | { error: string } {
  if (board.length !== 9) return { error: 'bad_board' };
  if (!Number.isInteger(cell) || cell < 0 || cell > 8) return { error: 'bad_cell' };
  if (board[cell] !== '.') return { error: 'cell_taken' };
  const b = board.split('');
  b[cell] = mark;
  const q = [...queue, cell];
  if (q.length > MAX_MARKS) b[q.shift()!] = '.';
  return { board: b.join(''), queue: q };
}

export function hasWon(board: string, mark: Mark): boolean {
  return LINES.some((l) => l.every((i) => board[i] === mark));
}
