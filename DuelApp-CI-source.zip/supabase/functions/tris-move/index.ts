// Edge Function: arbitro server-autoritativo di Tris Pro.
// Deploy: supabase functions deploy tris-move
import { createClient } from 'https://esm.sh/@supabase/supabase-js@2';
import { hasWon, MAX_MOVES, place, type Mark } from './tris.ts';

const TIMEOUT_MS = 5 * 60 * 1000;
const cors = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};
const json = (body: unknown, status = 200) =>
  new Response(JSON.stringify(body), { status, headers: { ...cors, 'Content-Type': 'application/json' } });

Deno.serve(async (req) => {
  if (req.method === 'OPTIONS') return new Response('ok', { headers: cors });
  try {
    const url = Deno.env.get('SUPABASE_URL')!;
    const userClient = createClient(url, Deno.env.get('SUPABASE_ANON_KEY')!, {
      global: { headers: { Authorization: req.headers.get('Authorization') ?? '' } },
    });
    const { data: { user } } = await userClient.auth.getUser();
    if (!user) return json({ error: 'unauthorized' }, 401);

    const admin = createClient(url, Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!);
    const { match_id, action, cell } = await req.json();

    const { data: m } = await admin
      .from('matches').select('*, games(slug)').eq('id', match_id).maybeSingle();
    if (!m) return json({ error: 'match_not_found' }, 404);
    if (m.games?.slug !== 'tris_pro') return json({ error: 'wrong_game' }, 400);
    if (m.player1_id !== user.id && m.player2_id !== user.id) return json({ error: 'forbidden' }, 403);
    if (m.status !== 'in_progress') return json({ error: 'match_over' }, 409);

    const me: Mark = user.id === m.player1_id ? 'x' : 'o';
    const opp: string = me === 'x' ? m.player2_id : m.player1_id;
    const gd = m.game_data;

    const finish = async (winner: string | null) => {
      const { error } = await admin.rpc('finish_match', { p_match: m.id, p_winner: winner });
      if (error) throw error;
    };

    if (action === 'resign') {
      await finish(opp);
      return json({ ok: true });
    }

    if (action === 'claim_timeout') {
      if (gd.turn === me) return json({ error: 'not_waiting_for_opponent' }, 400);
      if (Date.now() - Number(gd.last_move_at) < TIMEOUT_MS) return json({ error: 'timeout_not_reached' }, 400);
      await finish(user.id);
      return json({ ok: true });
    }

    if (action !== 'move') return json({ error: 'unknown_action' }, 400);
    if (gd.turn !== me) return json({ error: 'not_your_turn' }, 400);

    const myQueue: number[] = gd[`queue_${me}`] ?? [];
    const res = place(gd.board, myQueue, Number(cell), me);
    if ('error' in res) return json({ error: res.error }, 400);

    const next: Mark = me === 'x' ? 'o' : 'x';
    const newMoves = gd.moves + 1;
    const newData = {
      ...gd,
      board: res.board,
      turn: next,
      moves: newMoves,
      [`queue_${me}`]: res.queue,
      last_move_at: Date.now(),
      last_move: Number(cell),
    };

    const { data: upd, error: updErr } = await admin
      .from('matches')
      .update({ game_data: newData })
      .eq('id', m.id)
      .eq('status', 'in_progress')
      .eq('game_data->>moves', String(gd.moves))
      .select('id');
    if (updErr) throw updErr;
    if (!upd || upd.length === 0) return json({ error: 'conflict_retry' }, 409);

    if (hasWon(res.board, me)) await finish(user.id);
    else if (newMoves >= MAX_MOVES) await finish(null);

    return json({ ok: true });
  } catch (e) {
    console.error(e);
    return json({ error: 'server_error' }, 500);
  }
});
