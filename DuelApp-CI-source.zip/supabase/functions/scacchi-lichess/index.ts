// Edge Function: Scacchi via Lichess (partita anonima "open challenge").
// Flusso: il bianco (player1) chiama 'start' -> creiamo la sfida su Lichess e salviamo i due link.
// Ogni giocatore apre il proprio link; 'sync' legge il risultato da Lichess e chiude il match.
// Deploy: supabase functions deploy scacchi-lichess
import { createClient } from 'https://esm.sh/@supabase/supabase-js@2';

const LICHESS = 'https://lichess.org';
const NEVER_STARTED_MS = 30 * 60 * 1000; // se la partita non parte entro 30 min: annullata, puntate restituite
const cors = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};
const json = (body: unknown, status = 200) =>
  new Response(JSON.stringify(body), { status, headers: { ...cors, 'Content-Type': 'application/json' } });

Deno.serve(async (req) => {
  if (req.method === 'OPTIONS') return new Response('ok', { headers: cors });
  try {
    const url = Deno.env.get('SUPABASE_URL')!;
    const userClient = createClient(url, Deno.env.get('SUPABASE_ANON_KEY')!, {
      global: { headers: { Authorization: req.headers.get('Authorization') ?? '' } },
    });
    const { data: { user } } = await userClient.auth.getUser();
    if (!user) return json({ error: 'unauthorized' }, 401);

    const admin = createClient(url, Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!);
    const { match_id, action } = await req.json();

    const { data: m } = await admin
      .from('matches').select('*, games(slug)').eq('id', match_id).maybeSingle();
    if (!m) return json({ error: 'match_not_found' }, 404);
    if (m.games?.slug !== 'scacchi') return json({ error: 'wrong_game' }, 400);
    if (m.player1_id !== user.id && m.player2_id !== user.id) return json({ error: 'forbidden' }, 403);
    if (m.status !== 'in_progress') return json({ error: 'match_over' }, 409);

    const gd = m.game_data;
    const elapsed = Date.now() - Date.parse(m.started_at);
    const finish = async (winner: string | null) => {
      const { error } = await admin.rpc('finish_match', { p_match: m.id, p_winner: winner });
      if (error) throw error;
    };

    if (action === 'start') {
      if (user.id !== m.player1_id) return json({ error: 'not_creator' }, 400);
      if (gd.lichess_id) return json({ ok: true });

      const body = new URLSearchParams({
        rated: 'false',
        variant: 'standard',
        'clock.limit': '600',
        'clock.increment': '0',
        rules: 'noRematch,noGiveTime',
      });
      const r = await fetch(`${LICHESS}/api/challenge/open`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/x-www-form-urlencoded', Accept: 'application/json' },
        body,
      });
      if (!r.ok) {
        console.error('lichess create failed', r.status, await r.text());
        return json({ error: 'lichess_error' }, 502);
      }
      const ch = await r.json();
      // la risposta puo' avere i campi al livello principale o dentro "challenge"
      const id = ch.challenge?.id ?? ch.id;
      const urlWhite = ch.urlWhite ?? ch.challenge?.urlWhite;
      const urlBlack = ch.urlBlack ?? ch.challenge?.urlBlack;
      if (!id || !urlWhite || !urlBlack) return json({ error: 'lichess_error' }, 502);

      const { error } = await admin
        .from('matches')
        .update({ game_data: { ...gd, lichess_id: id, url_white: urlWhite, url_black: urlBlack, last_move_at: Date.now() } })
        .eq('id', m.id)
        .eq('status', 'in_progress');
      if (error) throw error;
      return json({ ok: true });
    }

    if (action === 'sync') {
      if (!gd.lichess_id) {
        if (elapsed > NEVER_STARTED_MS) {
          await finish(null);
          return json({ ok: true, result: 'cancelled' });
        }
        return json({ ok: true, pending: true });
      }

      const r = await fetch(`${LICHESS}/game/export/${gd.lichess_id}`, { headers: { Accept: 'application/json' } });
      if (r.status === 404) {
        // nessuno ha ancora accettato la sfida: la partita non esiste su Lichess
        if (elapsed > NEVER_STARTED_MS) {
          await finish(null);
          return json({ ok: true, result: 'cancelled' });
        }
        return json({ ok: true, pending: true });
      }
      if (!r.ok) return json({ error: 'lichess_error' }, 502);

      const g = await r.json();
      const st: string = g.status;
      if (st === 'created' || st === 'started') {
        if (st === 'created' && elapsed > NEVER_STARTED_MS) {
          await finish(null);
          return json({ ok: true, result: 'cancelled' });
        }
        return json({ ok: true, status: st });
      }

      // partita finita: winner = 'white' | 'black'; assente in patta/abort -> puntate restituite
      if (g.winner === 'white') await finish(m.player1_id);
      else if (g.winner === 'black') await finish(m.player2_id);
      else await finish(null);
      return json({ ok: true, result: 'finished', status: st });
    }

    return json({ error: 'unknown_action' }, 400);
  } catch (e) {
    console.error(e);
    return json({ error: 'server_error' }, 500);
  }
});
