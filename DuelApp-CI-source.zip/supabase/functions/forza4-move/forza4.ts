// Forza 4 - logica pura, eseguita SOLO sul server.
// Board: 42 caratteri (6 righe x 7 colonne), riga 0 in alto. 'r' rosso, 'y' giallo, '.' vuoto.
export type Disc = 'r' | 'y';
export const ROWS = 6;
export const COLS = 7;

export function drop(board: string, col: number, disc: Disc):
  { board: string; row: number } | { error: string } {
  if (board.length !== ROWS * COLS) return { error: 'bad_board' };
  if (!Number.isInteger(col) || col < 0 || col >= COLS) return { error: 'bad_column' };
  for (let r = ROWS - 1; r >= 0; r--) {
    const i = r * COLS + col;
    if (board[i] === '.') return { board: board.slice(0, i) + disc + board.slice(i + 1), row: r };
  }
  return { error: 'column_full' };
}

export function wins(board: string, row: number, col: number): boolean {
  const d = board[row * COLS + col];
  if (d === '.') return false;
  for (const [dr, dc] of [[0, 1], [1, 0], [1, 1], [1, -1]]) {
    let n = 1;
    for (const s of [1, -1]) {
      let r = row + dr * s, c = col + dc * s;
      while (r >= 0 && r < ROWS && c >= 0 && c < COLS && board[r * COLS + c] === d) {
        n++;
        r += dr * s;
        c += dc * s;
      }
    }
    if (n >= 4) return true;
  }
  return false;
}
