// Dama italiana - logica pura, eseguita SOLO sul server.
// Board: stringa di 64 caratteri, riga 0 in alto. w/b = pedine, W/B = dame, '.' = vuoto.
// Bianco muove verso l'alto (righe decrescenti). Case scure: (riga + colonna) dispari.
// Regole: presa obbligatoria, pedina non mangia dama, pedina e dama muovono/mangiano di 1 casa,
// presa multipla in una sola mossa, promozione che termina la mossa.
// Presa maggioritaria con spareggio per qualita' (regola ufficiale), nell'ordine:
//   1. si deve prendere il maggior numero di pezzi;
//   2. a parita', si deve prendere con la dama (se una dama puo' farlo);
//   3. a parita', la sequenza che cattura piu' dame;
//   4. a parita', quella che cattura una dama per prima.
// I pezzi catturati restano sulla scacchiera fino a fine mossa: non si possono saltare due volte
// e occupano la casa; il pezzo che muove puo' invece ripassare dalla propria casa di partenza.

export type Side = 'w' | 'b';
type Capture = { to: number; cap: number };

const row = (i: number) => Math.floor(i / 8);
const col = (i: number) => i % 8;
const inb = (r: number, c: number) => r >= 0 && r < 8 && c >= 0 && c < 8;
const isKing = (p: string) => p === 'W' || p === 'B';
const owner = (p: string): Side | null => (p === '.' ? null : (p.toLowerCase() as Side));

function dirs(p: string): [number, number][] {
  if (isKing(p)) return [[-1, -1], [-1, 1], [1, -1], [1, 1]];
  return p === 'w' ? [[-1, -1], [-1, 1]] : [[1, -1], [1, 1]];
}

function simpleMoves(b: string[], from: number): number[] {
  const out: number[] = [];
  for (const [dr, dc] of dirs(b[from])) {
    const r = row(from) + dr, c = col(from) + dc;
    if (inb(r, c) && b[r * 8 + c] === '.') out.push(r * 8 + c);
  }
  return out;
}

function captures(b: string[], piece: string, from: number, taken: number[] = []): Capture[] {
  const out: Capture[] = [];
  const me = owner(piece);
  for (const [dr, dc] of dirs(piece)) {
    const r1 = row(from) + dr, c1 = col(from) + dc;
    const r2 = r1 + dr, c2 = c1 + dc;
    if (!inb(r2, c2)) continue;
    const mid = b[r1 * 8 + c1];
    if (mid === '.' || owner(mid) === me) continue;
    if (taken.includes(r1 * 8 + c1)) continue; // gia' catturato in questa mossa
    if (!isKing(piece) && isKing(mid)) continue; // la pedina non mangia la dama
    if (b[r2 * 8 + c2] !== '.') continue;
    out.push({ to: r2 * 8 + c2, cap: r1 * 8 + c1 });
  }
  return out;
}

function promote(p: string, idx: number): string {
  if (p === 'w' && row(idx) === 0) return 'W';
  if (p === 'b' && row(idx) === 7) return 'B';
  return p;
}

function mustCapture(b: string[], side: Side): boolean {
  for (let i = 0; i < 64; i++) {
    if (owner(b[i]) === side && captures(b, b[i], i).length > 0) return true;
  }
  return false;
}

export function hasAnyMove(board: string, side: Side): boolean {
  const b = board.split('');
  for (let i = 0; i < 64; i++) {
    if (owner(b[i]) !== side) continue;
    if (simpleMoves(b, i).length > 0 || captures(b, b[i], i).length > 0) return true;
  }
  return false;
}

type Seq = { path: number[]; caps: number[]; kingMover: boolean; kings: number; firstKing: number };

// Tutte le sequenze di presa complete (non prolungabili) di `side`.
function allSequences(base: string[], side: Side): Seq[] {
  const out: Seq[] = [];
  for (let from = 0; from < 64; from++) {
    const piece = base[from];
    if (owner(piece) !== side) continue;
    const b = base.slice();
    b[from] = '.'; // la casa di partenza e' libera durante la mossa
    const dfs = (p: string, pos: number, path: number[], caps: number[]) => {
      const opts = captures(b, p, pos, caps);
      if (opts.length === 0) {
        if (caps.length > 0) out.push(mkSeq(base, piece, path, caps));
        return;
      }
      for (const c of opts) {
        const np = promote(p, c.to);
        const npath = [...path, c.to], ncaps = [...caps, c.cap];
        if (np !== p) out.push(mkSeq(base, piece, npath, ncaps)); // la promozione termina la mossa
        else dfs(np, c.to, npath, ncaps);
      }
    };
    dfs(piece, from, [from], []);
  }
  return out;
}

function mkSeq(base: string[], piece: string, path: number[], caps: number[]): Seq {
  const idx = caps.findIndex((i) => isKing(base[i]));
  return {
    path, caps,
    kingMover: isKing(piece),
    kings: caps.filter((i) => isKing(base[i])).length,
    firstKing: idx < 0 ? Infinity : idx,
  };
}

// Applica i criteri di qualita': restano solo le sequenze consentite.
function legalSequences(all: Seq[]): Seq[] {
  if (all.length === 0) return [];
  const maxLen = Math.max(...all.map((s) => s.caps.length));
  let s = all.filter((x) => x.caps.length === maxLen);
  if (s.some((x) => x.kingMover)) s = s.filter((x) => x.kingMover);
  const maxKings = Math.max(...s.map((x) => x.kings));
  s = s.filter((x) => x.kings === maxKings);
  const first = Math.min(...s.map((x) => x.firstKing));
  return s.filter((x) => x.firstKing === first);
}

// Numero di pezzi da catturare nella mossa obbligatoria (0 = nessuna presa possibile).
export function maxCaptureLen(boardStr: string, side: Side): number {
  const all = allSequences(boardStr.split(''), side);
  return all.length === 0 ? 0 : Math.max(...all.map((s) => s.caps.length));
}

// Classificazione di una mossa gia' validata: serve per le regole di pareggio.
export function describeMove(boardBefore: string, path: number[]): { capture: boolean; kingMove: boolean } {
  const capture = Math.abs(row(path[1]) - row(path[0])) === 2;
  return { capture, kingMove: isKing(boardBefore[path[0]]) };
}

// Chiave di posizione (scacchiera + chi muove) per la ripetizione.
export function positionKey(board: string, turn: Side): string {
  return `${board}${turn}`;
}

// path = [casa di partenza, casa 1, casa 2, ...]
export function applyPath(boardStr: string, side: Side, path: number[]): { board: string } | { error: string } {
  if (boardStr.length !== 64) return { error: 'bad_board' };
  if (path.length < 2) return { error: 'path_too_short' };
  if (path.some((i) => !Number.isInteger(i) || i < 0 || i > 63)) return { error: 'bad_square' };

  const b = boardStr.split('');
  const from = path[0];
  const piece = b[from];
  if (owner(piece) !== side) return { error: 'not_your_piece' };

  // mossa semplice
  if (Math.abs(row(path[1]) - row(from)) === 1) {
    if (path.length !== 2) return { error: 'bad_path' };
    if (mustCapture(b, side)) return { error: 'capture_required' };
    if (!simpleMoves(b, from).includes(path[1])) return { error: 'illegal_move' };
    b[from] = '.';
    b[path[1]] = promote(piece, path[1]);
    return { board: b.join('') };
  }

  // presa (anche multipla): il percorso deve coincidere con una sequenza completa e consentita
  const all = allSequences(b, side);
  const same = (x: number[]) => x.length === path.length && x.every((v, i) => v === path[i]);
  const exact = all.find((s) => same(s.path));
  if (!exact) {
    const partial = all.some((s) => s.path.length > path.length && path.every((v, i) => v === s.path[i]));
    return { error: partial ? 'must_continue_capture' : 'illegal_capture' };
  }
  if (!legalSequences(all).includes(exact)) return { error: 'must_capture_max' };
  b[from] = '.';
  for (const i of exact.caps) b[i] = '.';
  const end = exact.path[exact.path.length - 1];
  b[end] = promote(piece, end);
  return { board: b.join('') };
}
