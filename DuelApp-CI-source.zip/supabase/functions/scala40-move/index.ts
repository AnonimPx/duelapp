import { createClient } from 'https://esm.sh/@supabase/supabase-js@2';
import { deck, validMeld, canOpen, type Card, type Meld } from './scala40.ts';

const cors = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
  'Access-Control-Allow-Methods': 'POST, OPTIONS',
};
const json = (body: unknown, status = 200) => new Response(JSON.stringify(body), {
  status,
  headers: { ...cors, 'Content-Type': 'application/json' },
});
const suits = new Set(['♣', '♦', '♥', '♠']);

type Player = { id: string; hand: Card[]; opened: boolean; score: number };
type GameState = {
  players: Player[];
  stock: Card[];
  discard: Card[];
  turn: number;
  phase: 'playing' | 'finished';
  last_move_at: number;
  moves: number;
  drawn?: boolean;
  drawn_card?: Card;
  melds: { owner: number; cards: Card[] }[];
  winner_id?: string;
};
class HttpError extends Error {
  constructor(public status: number, message: string) { super(message); }
}
function fail(status: number, message: string): never { throw new HttpError(status, message); }
function validCard(value: unknown): value is Card {
  if (!value || typeof value !== 'object') return false;
  const c = value as Card;
  if (c.joker !== undefined && typeof c.joker !== 'boolean') return false;
  if (c.joker === true) return c.rank === 0 && c.suit === '♣';
  return Number.isInteger(c.rank) && c.rank >= 1 && c.rank <= 13 && suits.has(c.suit);
}
function same(a: Card, b: Card): boolean {
  return a.rank === b.rank && a.suit === b.suit && !!a.joker === !!b.joker;
}
function randomInt(max: number): number {
  const span = 0x1_0000_0000;
  const ceiling = span - (span % max);
  const sample = new Uint32Array(1);
  do { crypto.getRandomValues(sample); } while (sample[0] >= ceiling);
  return sample[0] % max;
}
function shuffle<T>(items: T[]): T[] {
  for (let i = items.length - 1; i > 0; i--) {
    const j = randomInt(i + 1);
    [items[i], items[j]] = [items[j], items[i]];
  }
  return items;
}
function validateIds(ids: unknown): asserts ids is string[] {
  if (!Array.isArray(ids) || ids.length < 2 || ids.length > 4 ||
      ids.some((id) => typeof id !== 'string') || new Set(ids).size !== ids.length) {
    fail(409, 'invalid_player_count');
  }
}
function initial(ids: string[]): GameState {
  validateIds(ids);
  const cards = shuffle(deck());
  const players = ids.map((id) => ({ id, hand: cards.splice(0, 13), opened: false, score: 0 }));
  return {
    players,
    stock: cards.slice(1),
    discard: [cards[0]],
    turn: 0,
    phase: 'playing',
    last_move_at: Date.now(),
    moves: 0,
    melds: [],
  };
}
function publicSummary(state: GameState): Record<string, unknown> {
  return {
    phase: state.phase,
    turn: state.turn,
    moves: state.moves,
    stock_count: state.stock.length,
    discard: state.discard,
    melds: state.melds ?? [],
    winner_id: state.winner_id ?? null,
    last_move_at: state.last_move_at,
    drawn: !!state.drawn,
    players: state.players.map((p) => ({
      id: p.id,
      cards_count: p.hand.length,
      opened: p.opened,
      score: p.score,
    })),
  };
}
function publicView(state: GameState, uid: string): Record<string, unknown> {
  const view = publicSummary(state);
  view.players = state.players.map((p) => ({
    id: p.id,
    cards_count: p.hand.length,
    opened: p.opened,
    score: p.score,
    ...(p.id === uid ? { hand: p.hand } : {}),
  }));
  return view;
}
function removeFromHand(hand: Card[], cards: Card[]): Card[] {
  let next = [...hand];
  for (const card of cards) {
    const at = next.findIndex((owned) => same(owned, card));
    if (at < 0) fail(400, 'card_not_in_hand');
    next.splice(at, 1);
  }
  return next;
}
function getMeldGroups(body: Record<string, unknown>): Meld[] {
  const raw = Array.isArray(body.melds) ? body.melds : [body.cards];
  if (!raw.length || raw.some((group) => !Array.isArray(group) || group.length < 3 || !group.every(validCard))) {
    fail(400, 'invalid_meld');
  }
  const groups = raw as Meld[];
  if (!groups.every(validMeld)) fail(400, 'invalid_meld');
  return groups;
}
function translateRpcError(message: string): HttpError {
  if (message.includes('stale_game_revision')) return new HttpError(409, 'stale_game_revision');
  if (message.includes('game_not_started')) return new HttpError(409, 'game_not_started');
  if (message.includes('game_already_started')) return new HttpError(409, 'game_already_started');
  if (message.includes('table_full')) return new HttpError(409, 'table_full');
  if (message.includes('invalid_player_count')) return new HttpError(409, 'invalid_player_count');
  if (message.includes('insufficient_funds')) return new HttpError(409, 'insufficient_funds');
  return new HttpError(500, 'server_error');
}

Deno.serve(async (req) => {
  if (req.method === 'OPTIONS') return new Response('ok', { headers: cors });
  if (req.method !== 'POST') return json({ error: 'method_not_allowed' }, 405);
  try {
    const url = Deno.env.get('SUPABASE_URL');
    const anonKey = Deno.env.get('SUPABASE_ANON_KEY');
    const serviceKey = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY');
    if (!url || !anonKey || !serviceKey) fail(500, 'server_configuration_error');
    const auth = createClient(url, anonKey, {
      global: { headers: { Authorization: req.headers.get('Authorization') ?? '' } },
      auth: { persistSession: false, autoRefreshToken: false },
    });
    const { data: { user }, error: authError } = await auth.auth.getUser();
    if (authError || !user) fail(401, 'unauthorized');
    const admin = createClient(url, serviceKey, { auth: { persistSession: false, autoRefreshToken: false } });
    let body: Record<string, unknown>;
    try {
      const parsed: unknown = await req.json();
      if (!parsed || typeof parsed !== 'object' || Array.isArray(parsed)) fail(400, 'invalid_request');
      body = parsed as Record<string, unknown>;
    } catch (error) {
      if (error instanceof HttpError) throw error;
      fail(400, 'invalid_json');
    }
    const matchId = body.match_id;
    const action = body.action;
    if (typeof matchId !== 'string' || typeof action !== 'string') fail(400, 'invalid_request');

    const { data: match, error: matchError } = await admin.from('matches')
      .select('id,game_id,player1_id,player2_id,player_ids,max_players,stake_gems,prize_gems,fee_gems,winner_id,status,game_data,games(slug)')
      .eq('id', matchId).maybeSingle();
    if (matchError) throw matchError;
    if (!match || (match.games as { slug?: string } | null)?.slug !== 'scala40') fail(404, 'match_not_found');
    const ids = (match.player_ids as string[] | null) ?? [match.player1_id, match.player2_id];
    validateIds(ids);
    if (!ids.includes(user.id)) fail(403, 'forbidden');

    const emptyView = (phase: string) => ({
      phase,
      turn: 0,
      moves: 0,
      stock_count: 0,
      discard: [],
      melds: [],
      winner_id: match.winner_id ?? null,
      last_move_at: null,
      drawn: false,
      players: ids.map((id) => ({ id, cards_count: 0, opened: false, score: 0 })),
    });
    if (match.status !== 'in_progress') {
      const { data: finishedState } = await admin.from('scala40_private_state').select('state')
        .eq('match_id', matchId).maybeSingle();
      const state = finishedState?.state as GameState | undefined;
      return json({ ok: true, state: state ? publicView(state, user.id) : emptyView('finished'),
        match_status: match.status, winner_id: match.winner_id ?? null });
    }

    if (action === 'state') {
      const { data: row, error } = await admin.from('scala40_private_state')
        .select('state,revision').eq('match_id', matchId).maybeSingle();
      if (error) throw error;
      const state = row?.state as GameState | undefined;
      if (state) state.melds ??= [];
      return json({ ok: true, state: state ? publicView(state, user.id) : emptyView('waiting'),
        match_status: match.status });
    }

    if (action === 'start') {
      const { data: startedIds, error: reserveError } = await admin.rpc('reserve_scala40_start', { p_match: matchId });
      if (reserveError) throw translateRpcError(reserveError.message);
      validateIds(startedIds);
      if (!startedIds.includes(user.id)) fail(403, 'forbidden');
      let { data: row, error } = await admin.from('scala40_private_state')
        .select('state,revision').eq('match_id', matchId).maybeSingle();
      if (error) throw error;
      if (!row) {
        const proposed = initial(startedIds);
        const inserted = await admin.from('scala40_private_state')
          .insert({ match_id: matchId, state: proposed, revision: 0 })
          .select('state,revision').maybeSingle();
        if (inserted.error && inserted.error.code !== '23505') throw inserted.error;
        row = inserted.data;
        if (!row) {
          const retry = await admin.from('scala40_private_state').select('state,revision')
            .eq('match_id', matchId).maybeSingle();
          if (retry.error || !retry.data) throw retry.error ?? new Error('state_initialization_failed');
          row = retry.data;
        }
      }
      const state = row.state as GameState;
      state.melds ??= [];
      const { error: commitError } = await admin.rpc('commit_scala40_state', {
        p_match: matchId,
        p_expected_revision: row.revision,
        p_state: state,
        p_public: publicSummary(state),
        p_winner: null,
      });
      if (commitError && !commitError.message.includes('stale_game_revision')) throw translateRpcError(commitError.message);
      const latest = await admin.from('scala40_private_state').select('state').eq('match_id', matchId).single();
      if (latest.error) throw latest.error;
      return json({ ok: true, state: publicView(latest.data.state as GameState, user.id), match_status: match.status });
    }

    if (action === 'finish') fail(400, 'finish_is_server_only');
    const { data: row, error: stateError } = await admin.from('scala40_private_state')
      .select('state,revision').eq('match_id', matchId).maybeSingle();
    if (stateError) throw stateError;
    if (!row) fail(409, 'game_not_started');
    const state = row.state as GameState;
    state.melds ??= [];
    if (state.phase !== 'playing') fail(409, 'match_finished');
    const playerIndex = state.players.findIndex((p) => p.id === user.id);
    if (playerIndex < 0) fail(403, 'not_seated');
    if (state.turn !== playerIndex) fail(409, 'not_your_turn');
    const player = state.players[playerIndex];
    let winner: string | null = null;

    if (action === 'draw') {
      if (state.drawn) fail(409, 'already_drawn');
      const fromDiscard = body.from_discard === true;
      if (!fromDiscard && state.stock.length === 0 && state.discard.length > 1) {
        const top = state.discard.pop()!;
        state.stock = shuffle(state.discard);
        state.discard = [top];
      }
      const card = fromDiscard ? state.discard.pop() : state.stock.pop();
      if (!card) fail(409, 'no_cards');
      player.hand.push(card);
      state.drawn = true;
      state.drawn_card = card;
    } else if (action === 'meld') {
      if (!state.drawn) fail(409, 'draw_first');
      const melds = getMeldGroups(body);
      const used = melds.flat();
      const nextHand = removeFromHand(player.hand, used);
      if (nextHand.length < 1) fail(400, 'must_keep_card_to_discard');
      if (!player.opened && !canOpen(melds)) fail(400, 'opening_requires_40');
      player.hand = nextHand;
      player.opened = true;
      state.melds.push(...melds.map((cards) => ({ owner: playerIndex, cards })));
    } else if (action === 'layoff') {
      if (!state.drawn) fail(409, 'draw_first');
      if (!player.opened) fail(400, 'must_open_first');
      const meldIndex = Number(body.meld_index);
      const cards = body.cards;
      if (!Number.isInteger(meldIndex) || meldIndex < 0 || meldIndex >= state.melds.length ||
          !Array.isArray(cards) || !cards.length || !cards.every(validCard)) fail(400, 'invalid_layoff');
      const next = [...state.melds[meldIndex].cards, ...(cards as Card[])];
      if (!validMeld(next)) fail(400, 'invalid_layoff');
      const nextHand = removeFromHand(player.hand, cards as Card[]);
      if (nextHand.length < 1) fail(400, 'must_keep_card_to_discard');
      player.hand = nextHand;
      state.melds[meldIndex].cards = next;
    } else if (action === 'discard') {
      if (!state.drawn) fail(409, 'draw_first');
      if (!validCard(body.card)) fail(400, 'invalid_card');
      if (state.drawn_card && same(state.drawn_card, body.card)) fail(400, 'cannot_discard_drawn_card');
      if (player.hand.length === 1 && !player.opened) fail(400, 'must_open_before_winning');
      player.hand = removeFromHand(player.hand, [body.card]);
      state.discard.push(body.card);
      state.drawn = false;
      delete state.drawn_card;
      state.moves++;
      if (player.hand.length === 0) {
        state.phase = 'finished';
        state.winner_id = user.id;
        winner = user.id;
      } else {
        state.turn = (playerIndex + 1) % state.players.length;
      }
    } else {
      fail(400, 'unknown_action');
    }

    state.last_move_at = Date.now();
    const { error: commitError } = await admin.rpc('commit_scala40_state', {
      p_match: matchId,
      p_expected_revision: row.revision,
      p_state: state,
      p_public: publicSummary(state),
      p_winner: winner,
    });
    if (commitError) throw translateRpcError(commitError.message);
    return json({ ok: true, state: publicView(state, user.id), match_status: winner ? 'finished' : 'in_progress' });
  } catch (error) {
    if (error instanceof HttpError) return json({ error: error.message }, error.status);
    console.error('scala40-move', error);
    return json({ error: 'server_error' }, 500);
  }
});
