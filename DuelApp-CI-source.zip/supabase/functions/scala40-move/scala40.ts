export type Suit = '♣' | '♦' | '♥' | '♠';
export type Card = { rank: number; suit: Suit; joker?: boolean };
export type Meld = Card[];

export function deck(): Card[] {
  const suits: Suit[] = ['♣', '♦', '♥', '♠'];
  const out: Card[] = [];
  for (let copy = 0; copy < 2; copy++) {
    for (const suit of suits) for (let rank = 1; rank <= 13; rank++) out.push({ rank, suit });
    out.push({ rank: 0, suit: '♣', joker: true }, { rank: 0, suit: '♣', joker: true });
  }
  return out;
}

export function cardPoints(c: Card): number { return c.joker ? 25 : c.rank === 1 ? 11 : Math.min(c.rank, 10); }
export function meldPoints(m: Meld): number { return m.reduce((s, c) => s + cardPoints(c), 0); }

export function isSet(m: Meld): boolean {
  if (m.length < 3 || m.length > 4 || m.filter((c) => c.joker).length > 1) return false;
  const real = m.filter((c) => !c.joker);
  if (real.length === 0 || real.some((c) => !Number.isInteger(c.rank) || c.rank < 1 || c.rank > 13)) return false;
  return new Set(real.map((c) => c.rank)).size === 1 && new Set(real.map((c) => c.suit)).size === real.length;
}

function isRunAtAceValue(m: Meld, aceValue: 1 | 14): boolean {
  if (m.length < 3 || m.length > 13 || m.filter((c) => c.joker).length > 1) return false;
  const real = m.filter((c) => !c.joker);
  if (real.length < 2 || real.some((c) => !Number.isInteger(c.rank) || c.rank < 1 || c.rank > 13)) return false;
  if (new Set(real.map((c) => c.suit)).size !== 1) return false;

  const ranks = real.map((c) => c.rank === 1 ? aceValue : c.rank).sort((a, b) => a - b);
  if (new Set(ranks).size !== ranks.length) return false;
  const span = ranks[ranks.length - 1] - ranks[0] + 1;
  if (span > m.length) return false;
  const earliestStart = Math.max(aceValue === 1 ? 1 : 2, ranks[ranks.length - 1] - m.length + 1);
  const latestStart = Math.min(ranks[0], 15 - m.length);
  return earliestStart <= latestStart;
}

export function isRun(m: Meld): boolean {
  // Scala 40 consente l'asso basso (A-2-3) o alto (Q-K-A), non il giro K-A-2.
  return isRunAtAceValue(m, 1) || isRunAtAceValue(m, 14);
}

export function validMeld(m: Meld): boolean { return isSet(m) || isRun(m); }
export function openingTotal(melds: Meld[]): number { return melds.filter(validMeld).reduce((s, m) => s + meldPoints(m), 0); }
export function canOpen(melds: Meld[]): boolean { return openingTotal(melds) >= 40; }

export function prize(stake: number, players: number): { gross: number; bank: number; payout: number } {
  if (!Number.isSafeInteger(stake) || stake < 1) throw new RangeError('stake_must_be_positive_integer');
  if (!Number.isInteger(players) || players < 2 || players > 4) throw new RangeError('players_must_be_between_2_and_4');
  const gross = stake * players;
  if (!Number.isSafeInteger(gross)) throw new RangeError('pot_overflow');
  const bank = Math.floor(gross * 20 / 100);
  return { gross, bank, payout: gross - bank };
}
