-- DuelApp — Scala 40 multiplayer: 2–4 giocatori, puntata per persona, fee 20%.
-- Da testare/applicare una sola volta dopo revisione. Lo script è idempotente per
-- colonne, tabelle e funzioni; preserva gli stati legacy spostandoli in storage privato.

insert into public.games (slug, name, type, is_active)
values ('scala40', 'Scala 40', 'internal', true)
on conflict (slug) do update set name = excluded.name, type = excluded.type, is_active = true;

alter table public.matches add column if not exists player_ids uuid[];
alter table public.matches add column if not exists max_players integer not null default 2;
update public.matches m
set player_ids = array[m.player1_id, m.player2_id]
where m.player_ids is null or cardinality(m.player_ids) = 0;
update public.matches m set max_players = 4
from public.games g where g.id = m.game_id and g.slug = 'scala40' and m.max_players = 2;
alter table public.matches alter column player_ids set not null;

-- Mani/mazzo fuori da matches.game_data, che è leggibile dai partecipanti.
create table if not exists public.scala40_private_state (
  match_id uuid primary key references public.matches(id) on delete cascade,
  state jsonb not null,
  revision bigint not null default 0 check (revision >= 0),
  updated_at timestamptz not null default now()
);
alter table public.scala40_private_state enable row level security;
revoke all on table public.scala40_private_state from public, anon, authenticated;
grant all on table public.scala40_private_state to service_role;

-- Importa gli stati vecchi prima di rimuovere le mani dal JSON pubblico.
insert into public.scala40_private_state(match_id, state, revision)
select m.id, m.game_data - 'player_ids' - 'player_count',
       greatest(coalesce((m.game_data->>'moves')::bigint, 0), 0)
from public.matches m
join public.games g on g.id = m.game_id and g.slug = 'scala40'
where jsonb_typeof(m.game_data->'players') = 'array'
  and jsonb_typeof(m.game_data->'stock') = 'array'
  and jsonb_typeof(m.game_data->'discard') = 'array'
on conflict (match_id) do nothing;

-- Rimuove vincoli legacy che presuppongono esattamente due quote o vincitore p1/p2.
do $$
declare c record;
begin
  for c in
    select conname from pg_constraint
    where conrelid = 'public.matches'::regclass and contype = 'c'
      and (pg_get_constraintdef(oid) ilike '%prize_gems%'
        or pg_get_constraintdef(oid) ilike '%fee_gems%'
        or pg_get_constraintdef(oid) ilike '%winner_id%')
  loop
    execute format('alter table public.matches drop constraint if exists %I', c.conname);
  end loop;
end $$;
alter table public.matches drop constraint if exists matches_winner_in_players;
alter table public.matches drop constraint if exists matches_scala40_economics;
alter table public.matches drop constraint if exists matches_max_players_range;
alter table public.matches drop constraint if exists matches_player_count_range;
alter table public.matches add constraint matches_max_players_range
  check (max_players between 2 and 4);
alter table public.matches add constraint matches_player_count_range
  check (cardinality(player_ids) between 2 and max_players);
alter table public.matches add constraint matches_winner_in_players
  check (winner_id is null or winner_id = any(player_ids));
alter table public.matches drop constraint if exists matches_fee_gems_check;
alter table public.matches drop constraint if exists matches_prize_gems_check;
alter table public.matches add constraint matches_fee_gems_check check (fee_gems >= 0);
alter table public.matches add constraint matches_prize_gems_check check (prize_gems >= 0);
alter table public.matches add constraint matches_scala40_economics
  check (
    (max_players = 4
      and fee_gems::bigint = (stake_gems::bigint * cardinality(player_ids) * 20) / 100
      and fee_gems::bigint + prize_gems::bigint = stake_gems::bigint * cardinality(player_ids))
    or (max_players = 2
      and fee_gems::bigint + prize_gems::bigint = stake_gems::bigint * 2)
  );

-- Riduce game_data alle sole informazioni pubbliche (senza mani o tallone).
update public.matches m
set game_data = (
select jsonb_build_object(
  'player_ids', to_jsonb(m.player_ids),
  'player_count', cardinality(m.player_ids),
  'phase', case when p.match_id is null then 'waiting' else coalesce(p.state->>'phase', 'playing') end,
  'turn', coalesce(p.state->'turn', '0'::jsonb),
  'moves', coalesce(p.state->'moves', '0'::jsonb),
  'stock_count', case when p.match_id is null then 0 else jsonb_array_length(coalesce(p.state->'stock', '[]'::jsonb)) end,
  'discard', coalesce(p.state->'discard', '[]'::jsonb),
  'melds', coalesce(p.state->'melds', '[]'::jsonb),
  'last_move_at', p.state->'last_move_at',
  'server_started_at', case when p.match_id is null then null else to_jsonb(now()) end,
  'players', case when p.match_id is null then
      (select coalesce(jsonb_agg(jsonb_build_object('id', x, 'cards_count', 0, 'opened', false, 'score', 0)), '[]'::jsonb)
       from unnest(m.player_ids) as x)
    else (select coalesce(jsonb_agg(jsonb_build_object(
        'id', pl.value->>'id',
        'cards_count', jsonb_array_length(coalesce(pl.value->'hand', '[]'::jsonb)),
        'opened', coalesce((pl.value->>'opened')::boolean, false),
        'score', coalesce((pl.value->>'score')::integer, 0)
      ) order by pl.ordinality), '[]'::jsonb)
      from jsonb_array_elements(p.state->'players') with ordinality as pl(value, ordinality))
  end
)
from public.games g
left join public.scala40_private_state p on p.match_id = m.id
where g.id = m.game_id and g.slug = 'scala40'
)
where exists (select 1 from public.games g where g.id = m.game_id and g.slug = 'scala40');

create or replace function public.sync_match_players()
returns trigger language plpgsql set search_path = '' as $$
declare v_slug text;
begin
  select g.slug into v_slug from public.games g where g.id = new.game_id;
  if new.player_ids is null or cardinality(new.player_ids) = 0 then
    new.player_ids := array[new.player1_id, new.player2_id];
  end if;
  if v_slug = 'scala40' then
    -- I tavoli Scala 40 usano la capienza massima prevista dal gioco.
    if new.max_players = 2 then new.max_players := 4; end if;
  else
    new.max_players := 2;
    new.player_ids := array[new.player1_id, new.player2_id];
  end if;
  return new;
end;
$$;
drop trigger if exists matches_sync_players on public.matches;
create trigger matches_sync_players before insert or update on public.matches
for each row execute function public.sync_match_players();

-- I tavoli aperti sono visibili; dopo l’avvio solo i partecipanti possono leggerli.
drop policy if exists "matches_select_participant" on public.matches;
create policy "matches_select_participant" on public.matches
for select to authenticated
using (
  auth.uid() = any(player_ids)
  or (
    status = 'in_progress'
    and max_players > cardinality(player_ids)
    and game_data->>'server_started_at' is null
    and exists (select 1 from public.games g where g.id = game_id and g.slug = 'scala40')
  )
);

create or replace function public.join_scala40(p_match uuid)
returns uuid language plpgsql security definer set search_path = '' as $$
declare
  v_uid uuid := auth.uid(); m public.matches; v_bal integer;
  v_players uuid[]; v_count integer; v_fee bigint; v_prize bigint;
begin
  if v_uid is null then raise exception 'not_authenticated'; end if;
  select m0.* into m from public.matches m0
    join public.games g on g.id = m0.game_id
    where m0.id = p_match and g.slug = 'scala40' for update of m0;
  if not found then raise exception 'scala40_match_not_found'; end if;
  if m.status <> 'in_progress' then raise exception 'match_not_available'; end if;
  v_players := m.player_ids;
  if v_uid = any(v_players) then return p_match; end if;
  if m.game_data->>'server_started_at' is not null
     or exists(select 1 from public.scala40_private_state s where s.match_id = p_match) then
    raise exception 'game_already_started';
  end if;
  if m.max_players < 2 or m.max_players > 4 or cardinality(v_players) >= m.max_players then
    raise exception 'table_full';
  end if;
  select w.balance_gems into v_bal from public.wallets w where w.user_id = v_uid for update;
  if not found then raise exception 'wallet_not_found'; end if;
  if v_bal < m.stake_gems then raise exception 'insufficient_funds'; end if;
  update public.wallets set balance_gems = balance_gems - m.stake_gems,
    hold_gems = hold_gems + m.stake_gems, updated_at = now() where user_id = v_uid;
  insert into public.transactions(user_id, match_id, type, amount_gems, balance_before, balance_after)
    values(v_uid, p_match, 'stake_hold', -m.stake_gems, v_bal, v_bal - m.stake_gems);
  v_players := array_append(v_players, v_uid);
  v_count := cardinality(v_players);
  v_fee := (m.stake_gems::bigint * v_count * 20) / 100;
  v_prize := m.stake_gems::bigint * v_count - v_fee;
  if v_fee > 2147483647 or v_prize > 2147483647 then raise exception 'pot_overflow'; end if;
  update public.matches set player_ids = v_players, fee_gems = v_fee::integer, prize_gems = v_prize::integer,
    game_data = jsonb_set(jsonb_set(coalesce(game_data, '{}'::jsonb), '{player_ids}', to_jsonb(v_players)), '{player_count}', to_jsonb(v_count))
    where id = p_match;
  return p_match;
end;
$$;
revoke all on function public.join_scala40(uuid) from public, anon;
grant execute on function public.join_scala40(uuid) to authenticated;

-- Serializza l'avvio contro una join concorrente; solo la Edge Function può invocarla.
create or replace function public.reserve_scala40_start(p_match uuid)
returns uuid[] language plpgsql security definer set search_path = '' as $$
declare m public.matches; v_ids uuid[];
begin
  select m0.* into m from public.matches m0 join public.games g on g.id = m0.game_id
    where m0.id = p_match and g.slug = 'scala40' for update of m0;
  if not found then raise exception 'scala40_match_not_found'; end if;
  if m.status <> 'in_progress' then raise exception 'match_not_available'; end if;
  v_ids := m.player_ids;
  if cardinality(v_ids) < 2 or cardinality(v_ids) > 4 then raise exception 'invalid_player_count'; end if;
  if m.game_data->>'server_started_at' is null then
    update public.matches set game_data = jsonb_set(coalesce(game_data, '{}'::jsonb), '{server_started_at}', to_jsonb(now()), true)
      where id = p_match;
  end if;
  return v_ids;
end;
$$;
revoke all on function public.reserve_scala40_start(uuid) from public, anon, authenticated;
grant execute on function public.reserve_scala40_start(uuid) to service_role;

-- Liquidazione server-only e idempotente: una quota per ogni partecipante.
create or replace function public.finish_scala40(p_match uuid, p_winner uuid)
returns void language plpgsql security definer set search_path = '' as $$
declare
  m public.matches; p uuid; v_hold integer; v_bal integer; v_ids uuid[];
begin
  select * into m from public.matches where id = p_match for update;
  if not found then raise exception 'match_not_found'; end if;
  if m.status <> 'in_progress' then return; end if;
  if not exists(select 1 from public.games g where g.id = m.game_id and g.slug = 'scala40') then
    raise exception 'not_scala40_match';
  end if;
  v_ids := m.player_ids;
  if cardinality(v_ids) < 2 or cardinality(v_ids) > 4 or not (p_winner = any(v_ids)) then
    raise exception 'invalid_winner';
  end if;
  perform 1 from public.wallets where user_id = any(v_ids) order by user_id for update;
  foreach p in array v_ids loop
    select hold_gems into v_hold from public.wallets where user_id = p;
    if not found or v_hold < m.stake_gems then raise exception 'stake_hold_missing'; end if;
  end loop;
  select balance_gems into v_bal from public.wallets where user_id = p_winner;
  update public.wallets set hold_gems = hold_gems - m.stake_gems,
    balance_gems = balance_gems + m.prize_gems, updated_at = now() where user_id = p_winner;
  insert into public.transactions(user_id, match_id, type, amount_gems, balance_before, balance_after)
    values(p_winner, p_match, 'win', m.prize_gems, v_bal, v_bal + m.prize_gems);
  foreach p in array v_ids loop
    if p <> p_winner then
      update public.wallets set hold_gems = hold_gems - m.stake_gems, updated_at = now() where user_id = p;
    end if;
  end loop;
  insert into public.platform_fees(match_id, fee_gems) values(p_match, m.fee_gems)
    on conflict (match_id) do nothing;
  update public.matches set status = 'finished', winner_id = p_winner, finished_at = now() where id = p_match;
end;
$$;
revoke all on function public.finish_scala40(uuid, uuid) from public, anon, authenticated;
grant execute on function public.finish_scala40(uuid, uuid) to service_role;

-- Commit atomico stato privato + snapshot pubblico + payout eventuale.
create or replace function public.commit_scala40_state(
  p_match uuid, p_expected_revision bigint, p_state jsonb, p_public jsonb, p_winner uuid default null
)
returns bigint language plpgsql security definer set search_path = '' as $$
declare v_revision bigint; v_ids uuid[]; v_count integer;
begin
  if p_public ? 'stock' or p_public ? 'hands'
     or exists(select 1 from jsonb_array_elements(coalesce(p_public->'players', '[]'::jsonb)) as player(value) where player.value ? 'hand') then
    raise exception 'private_cards_in_public_payload';
  end if;
  perform 1 from public.matches where id = p_match and status = 'in_progress' for update;
  if not found then raise exception 'match_not_available'; end if;
  select revision into v_revision from public.scala40_private_state where match_id = p_match for update;
  if not found then raise exception 'game_not_started'; end if;
  if v_revision <> p_expected_revision then raise exception 'stale_game_revision'; end if;
  update public.scala40_private_state set state = p_state, revision = v_revision + 1, updated_at = now()
    where match_id = p_match;
  select player_ids into v_ids from public.matches where id = p_match;
  v_count := cardinality(v_ids);
  update public.matches set game_data = p_public || jsonb_build_object(
      'player_ids', to_jsonb(v_ids), 'player_count', v_count,
      'server_started_at', coalesce(nullif(game_data->'server_started_at', 'null'::jsonb), to_jsonb(now()))
    ) where id = p_match;
  if p_winner is not null then perform public.finish_scala40(p_match, p_winner); end if;
  return v_revision + 1;
end;
$$;
revoke all on function public.commit_scala40_state(uuid, bigint, jsonb, jsonb, uuid) from public, anon, authenticated;
grant execute on function public.commit_scala40_state(uuid, bigint, jsonb, jsonb, uuid) to service_role;

-- Permessi espliciti: nessun client può scrivere direttamente match o mani.
revoke insert, update, delete on public.scala40_private_state from anon, authenticated;
